Src/stm32_adafruit_lcd.o: ../Src/stm32_adafruit_lcd.c \
 ../Inc/stm32_adafruit_lcd.h ../Inc/st7735.h ../Inc/lcd.h \
 ../Inc/Fonts/fonts.h ../Inc/Fonts/font24.c ../Inc/Fonts/fonts.h \
 ../Inc/Fonts/font20.c ../Inc/Fonts/font16.c ../Inc/Fonts/font12.c \
 ../Inc/Fonts/font8.c
../Inc/stm32_adafruit_lcd.h:
../Inc/st7735.h:
../Inc/lcd.h:
../Inc/Fonts/fonts.h:
../Inc/Fonts/font24.c:
../Inc/Fonts/fonts.h:
../Inc/Fonts/font20.c:
../Inc/Fonts/font16.c:
../Inc/Fonts/font12.c:
../Inc/Fonts/font8.c:
