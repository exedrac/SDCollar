Src/msoe_stm_lcd.o: ../Src/msoe_stm_lcd.c ../Inc/msoe_stm_lcd.h \
 ../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u575xx.h \
 ../Drivers/CMSIS/Include/core_cm33.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv8.h \
 ../Drivers/CMSIS/Device/ST/STM32U5xx/Include/system_stm32u5xx.h \
 ../Inc/st7735.h ../Inc/lcd.h ../Inc/stm32_adafruit_lcd.h \
 ../Inc/Fonts/fonts.h ../Inc/st7735.h ../Inc/stm32_adafruit_lcd.h
../Inc/msoe_stm_lcd.h:
../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u575xx.h:
../Drivers/CMSIS/Include/core_cm33.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv8.h:
../Drivers/CMSIS/Device/ST/STM32U5xx/Include/system_stm32u5xx.h:
../Inc/st7735.h:
../Inc/lcd.h:
../Inc/stm32_adafruit_lcd.h:
../Inc/Fonts/fonts.h:
../Inc/st7735.h:
../Inc/stm32_adafruit_lcd.h:
