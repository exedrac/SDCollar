Src/st7735.o: ../Src/st7735.c ../Inc/st7735.h ../Inc/lcd.h
../Inc/st7735.h:
../Inc/lcd.h:
