/*
 * msoe_stm_lcd.c
 *
 *  Created on: Jun 12, 2023
 *      Author: widder
 *
 *        Change log:
 *        Date		Eng.	Description
 *        5/21/24	krw		Added clearing of garbage on right and bottom edges in LCD_clear()
 *        5/21/24	krw		Changed string argument in LCD_print_str() to unsigned char *pStr
 *        						to remove warnings
 *        5/24/24	krw		Fix for residual exponent digit if zero gets overwritten
 *        8/12/24	krw		Added drawing functions - pixel, lines, etc.
 *
 *
 */

//  Source files for interfacing the STM32U575 to the Adafruit
//  1.44" 128 x 128 color TFT LCD using the ST7735 chip.
//  With the 12-font, it has 10 rows and 18 columns of characters.
//  The numbering starts at the top-left corner (0, 0)
//  Uses functions from STM and Adafruit
//
//  Initialize the LCD before use via the function LCD_IO_Init().
//  Other functions available are:
//    LCD_clear()		clears the screen
//    LCD_print_char(uint8_t row, uint8_t col, uint8_t Ascii)		write a character
//    LCD_print_str(uint8_t row, uint8_t col, unsigned char *pStr)			write a string
//    LCD_print_bin8(uint8_t row, uint8_t col, uint8_t val)			8-bit number in binary
//    LCD_print_bin16(uint8_t row, uint8_t col, uint16_t val)		16-bit number in binary
//    LCD_print_hex8(uint8_t row, uint8_t col, uint8_t val)			8-bit number in hexadecimal (hex)
//    LCD_print_hex16(uint8_t row, uint8_t col, uint16_t val)		16-bit number in hex
//    LCD_print_hex32(uint8_t row, uint8_t col, uint32_t val)		32-bit number in hex
//    LCD_print_udec3(uint8_t row, uint8_t col, uint8_t val)		8-bit unsigned int (3 digits)
//    LCD_print_udec5(uint8_t row, uint8_t col, uint16_t val)
//    LCD_print_udec10(uint8_t row, uint8_t col, uint32_t val)
//    LCD_print_dec3(uint8_t row, uint8_t col, int8_t val)			8-bit signed int (3 digits)
//    LCD_print_dec5(uint8_t row, uint8_t col, int16_t val)
//    LCD_print_dec10(uint8_t row, uint8_t col, int32_t val)
//    LCD_print_float(uint8_t row, uint8_t col, float val)			floating point value
//	  LCD_print_pixel(uint16_t Xpos, uint16_t Ypos, uint16_t RGB_Code)
//	  LCD_print_HLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length)
//	  LCD_print_VLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length)
//	  LCD_print_Line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
//	  LCD_print_Rect(uint16_t Xpos, uint16_t Ypos, uint16_t Width, uint16_t Height)
//	  LCD_print_Circle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius)
//	  LCD_print_Ellipse(int Xpos, int Ypos, int XRadius, int YRadius)
//	  LCD_print_Bitmap(uint16_t Xpos, uint16_t Ypos, uint8_t *pBmp)
//
//
////////////////////////////////////////////////////////////////
//
// Connection name / Adafruit LCD Module / STM32U575 Hardware Configuration (pinout)
//
// Vin						pin 1		3.3V	CN8-7
// 3v3 out					pin 2		N/C
// GND        				pin 3		GND		CN10-22
// SCK 					   	pin 4		PE13	CN10-10
// SO         				pin 5		PE14	CN10-28
// SI						pin 6		PE15	CN10-30
// TCS			   			pin 7 		PE12	CN10-23
// RST       				pin 8		PE9		CN10-4		Active LOW
// D/C (data/commandBar)	pin 9		PE10	CN10-24		command LOW
// CCS       				pin 10		PE8		CN10-18		Active LOW
// Lite			    		pin 11 		N/C
//
////////////////////////////////////////////////////////////////


#include <float.h>
#include <msoe_stm_lcd.h>
#include "st7735.h"
#include "stm32_adafruit_lcd.h"


/********************************* LINK LCD ***********************************/
/**
  * @brief  Writes a command to the LCD .
  * @param  LCDReg Address of the selected register.
  * @retval None
  */
void LCD_IO_WriteReg(uint8_t LCDReg)
{
	// wait for availability
	while(!(SPI1->SR & (1 << 12)))
		;

	/* Set LCD data/command line DC to Low for command */
	GPIOE->BRR |= (1 << 10);

	/* Send Command */
	*((volatile uint8_t*) &(SPI1->TXDR)) = LCDReg;

	// set CSTART bit
	SPI1->CR1 |= (1 << 9);
	// wait for completion
	while(!(SPI1->SR & (1 << 12)))
		;

	return;
}

/**
  * @brief  Writes data to the seleced LCD register.
  *         This function must be used after st7735_WriteReg() function
  * @param  Data data to write to the selected register.
  * @retval None
  */
void LCD_IO_WriteData(uint8_t Data)
{
	/* Set LCD data/command line DC to high for data */
	GPIOE->BSRR |= (1 << 10);

	// wait for completion
	while(!(SPI1->SR & (1 << 12)))
		;

	/* Send Command */
	*((volatile uint8_t*) &(SPI1->TXDR)) = Data;

	// set CSTART bit
	SPI1->CR1 |= (1 << 9);
	// wait for completion
	while(!(SPI1->SR & (1 << 12)))
		;
}

/**
* @brief  Write register value.
* @param  pData Pointer on the register value
* @param  Size number of bytes to transmit to the register
* @retval None
*/
void LCD_IO_WriteMultipleData(uint8_t *pData, uint32_t Size)
{
	uint32_t counter = 0;

	/* Set LCD data/command line DC to high for data */
	GPIOE->BSRR |= (1 << 10);

	if (Size == 1)
	{
		/* Only 1 byte to be sent to LCD - general interface can be used */
		// wait for completion
		while(!(SPI1->SR & (1 << 12)))
			;

		/* Send data */
		*((volatile uint8_t*) &(SPI1->TXDR)) = *pData;
		// set CSTART bit
		SPI1->CR1 |= (1 << 9);
		// wait for completion
		while(!(SPI1->SR & (1 << 12)))
			;
	}
	else
	{
		/* Several data should be sent in a row */
		/* Direct SPI accesses for optimization */
		for (counter = Size; counter != 0; counter--)
		{
			while(!(SPI1->SR & (1 << 12)))
			{
			}
			/* Send data */
			*((volatile uint8_t*) &(SPI1->TXDR)) = *pData;
			// set CSTART bit
			SPI1->CR1 |= (1 << 9);
			// wait for completion
			while(!(SPI1->SR & (1 << 12)))
				;
			pData++;
		}
	}
	//  /* Empty the Rx fifo */
	//  data = *(&hnucleo_Spi.Instance->DR);
	//  UNUSED(data);
}

/**
  * @brief  Wait for loop .
  * @param  Delay .
  * @retval None
  */
void LCD_Delay(uint32_t Delay)
{
  uint32_t i;
  for(i=0; i<Delay; i++)
	  ;
}

/**
  * @brief  Initializes the LCD interface pins (SPI1)
  * @retval None
  */
void LCD_GPIO_Config(void)
{
	//Turn on GPIO clock for port E
	RCC->AHB2ENR1 |= 0x00000010; // enable GPIOe clock

	// configure GPIO pins for SPI1 use
	// set MODER bits for alternate function for SCK, MISO, MOSI and SS
	// set MODER bits for GPIO output for rest (RST, D/C, CARD_CS)
	GPIOE->MODER &= ~((0b01 << 22) | (0b01 << 24) | (0b01 << 26) |
			(0b01 << 28) | (0b01 << 30) );
	GPIOE->MODER &= ~((0b10 << 16) | (0b10 << 18) | (0b10 << 20) );
	// OTYPER - leave at default - push-pull
	// speed - set to high speed
	GPIOE->OSPEEDR |= ((0b10 << 22) | (0b10 << 24) | (0b10 << 26) |
			(0b10 << 28) | (0b10 << 30) | (0b10 << 16) |
			(0b10 << 18) | (0b10 << 20));
	// PUPDR - leave at default none for sclk and mosi, pull up for miso and ss and rdy
	GPIOE->PUPDR |= ((0b01 << 28) | (0b01 << 24) | (0b01 << 22));
	// start D/C bit low
	GPIOE->BRR |= (1 << 10);
	// start RST and CARD_CS high
	GPIOE->BSRR |= ((1 << 9) | (1 << 8)) ;
	// setup alt. function
	GPIOE->AFR[1] |= ((0b0101 << 12) | (0b0101 << 16) | (0b0101 << 20) |
			(0b0101 << 24) | (0b0101 << 28) );

	return;
}

/********************************* LINK LCD ***********************************/
/**
  * @brief  Initializes the SPI1 peripheral for communication with the LCD
  * @retval None
  */
void LCD_SPI_Config(void)
{
	//
	RCC->CR |= (1 << 4);  // enable MSIK clock
	RCC->APB2ENR |= (1 << 12); // enable SPI1 clock
	RCC->CCIPR1 |= (3 << 20);  // select MSIK for SPI1 kernel clock (4 MHz)

	// make sure SPE = 0 so config can occur
	SPI1->CR1 &= ~(1 << 0);
	// SPI1 setup
	// reg. CFG1 : BPASS[31] = 1 bypass baud prescaler
	//      no CRC, no DMA, FIFO threshold level (default) = 1,
	//      8-bits per frame (default)
	SPI1->CFG1 |= (1 << 31);
	// reg. CFG2 : AFCNTR = 1 hold GPIO when disabled, SSOM = 0 SS active til data done,
	//      SSOE = 1 SS enabled, SSIOP = 0 active low, SSM = 0 SS hdwr control,
	//      CPOL = 0 SCL low at idle, CPHA = 0 first clk change is first capture edge,
	//      LSBFRST = 0 MSB first, MASTER = 1 master, SP = 000 Moto,
	//      COMM = 00 full duplex, MIDI = 0001 one clock idle SS between frames,
	//      MSSI = 0000 no extra delay SS to data
	SPI1->CFG2 |= ((1 << 31) | (1 << 29) | (1 << 22) | (1 << 4));
	// enable SPI1
	SPI1->CR1 |= (1 << 0);

	return;
}

/********************************* LINK LCD ***********************************/
/**
  * @brief  Initializes the LCD
  * @retval None
  */
void LCD_IO_Init(void)
{
	LCD_GPIO_Config();
	LCD_SPI_Config();

	// reset LCD - active low, 10 us pulse, then wait 5 ms
	//    before sending commands (RST on PE9)
	LCD_Delay(2000);
	GPIOE->BRR |= (1 << 9);
	LCD_Delay(2000);
	GPIOE->BSRR |= (1 << 9);
	LCD_Delay(1000000);

	// setup LCD controller
	st7735_Init();
	BSP_LCD_Init();
	st7735_DisplayOn();
	BSP_LCD_Clear(LCD_COLOR_BLACK);
	st7735_SetCursor(0, 0);

	/* Initialize the font */
	BSP_LCD_SetFont(&LCD_DEFAULT_FONT);
	return;
}

/**
* @brief  Clear LCD screen
* @param  None
* @retval None
*/
void LCD_clear(void)
{
	// erase the LCD screen
	BSP_LCD_Clear(LCD_COLOR_BLACK);
	// clear residuals on right and bottom edges
	for (int i = 0; i < 10; i++)
	{
		LCD_print_char(i, 18, ' ');
	}
	for (int i = 0; i <= 18; i++)
	{
		LCD_print_char(10, i, ' ');
	}
	return;
}

/**
* @brief  print a character to the LCD.
* @param  row Row to print in
* @param  col Column to start in
* @param  Ascii Character (in ASCII) to print
* @retval None
*/
void LCD_print_char(uint8_t row, uint8_t col, uint8_t Ascii)
{
	// calculate starting pixel location
	//  font12  (7 x 12), rows 0 - 11, cols 0 - 17
	uint16_t xpos, ypos;
	xpos = COLUMN(col) ;
	ypos = LINE(row) ;
	BSP_LCD_DisplayChar(xpos, ypos,  Ascii);
	return;
}


/**
* @brief  print a string to the LCD.
* @param  row Row to print in
* @param  col Column to start in
* @param  Pointer to string data to print
* @retval None
*/
void LCD_print_str(uint8_t row, uint8_t col, unsigned char *pStr)
{
	// calculate starting pixel location
	//  font12  (7 x 12), rows 0 - 11, cols 0 - 17
	uint16_t xpos, ypos;
	xpos = COLUMN(col) ;
	ypos = LINE(row) ;
	BSP_LCD_DisplayStringAt(xpos, ypos,  (uint8_t *)pStr, LEFT_MODE);
	return;
}

///////////   Number display routines   ///////////////////////////
//
/**
* @brief  Display binary
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

 // Bitwise AND the value with each binary value then logical AND with 1
 //   Offset by 0x30 to convert to ASCII
void LCD_print_bin8(uint8_t row, uint8_t col, uint8_t val)
{
	int8_t i;
	LCD_print_char(row, col, '0');
	col++;
	LCD_print_char(row, col, 'b');
	col++;
	for(i=8; i>0; i--)
	{
		LCD_print_char(row, col, (char)(val & (1 << (i-1)) && 1) + 0x30);
		col++;
	}
	return;
}
//
void LCD_print_bin16(uint8_t row, uint8_t col, uint16_t val)
{
	int i;
	LCD_print_char(row, col, '0');
	col++;
	LCD_print_char(row, col, 'b');
	col++;
	for(i=16; i>0; i--)
	{
		LCD_print_char(row, col, (char)(val & (1 << (i-1)) && 1) + 0x30);
		col++;
	}
	return;
}

/**
* @brief  Display 8 bit Hex
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*///
//
// Break the value into two nibbles
// check for 0-9 vs A-F and add appropriate ASCII offsets
// Output each nibble
void LCD_print_hex8(uint8_t row, uint8_t col, uint8_t val)
{
	uint8_t val_tmp;
	LCD_print_char(row, col, '0');
	col++;
	LCD_print_char(row, col, 'x');
	col++;
	val_tmp = val >> 4;
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	col++;
	val_tmp = (val & 0x0F);
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	return;
}

/**
* @brief  Display  16bit Hex
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*///
// Display 16 bit Hex
//
// Break the value into four nibbles
// check for 0-9 vs A-F and add appropriate ASCII offsets
// Output each nibble
void LCD_print_hex16(uint8_t row, uint8_t col, uint16_t val)
{
	uint16_t val_tmp;
	LCD_print_char(row, col, '0');
	col++;
	LCD_print_char(row, col, 'x');
	col++;
	val_tmp = val >> 12;
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	col++;
	val_tmp = val & 0x0FFF;
	val_tmp = val_tmp >> 8;
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	col++;
	val_tmp = val & 0x00FF;
	val_tmp = val_tmp >> 4;
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	col++;
	val_tmp = (val & 0x0F);
	if(val_tmp < 10)
		LCD_print_char(row, col, val_tmp + 0x30);
	else
		LCD_print_char(row, col, val_tmp + 0x37);
	return;
}

/**
* @brief  Display 32 bit Hex
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*///
// Display 32 bit Hex
//
// Break the value into eight nibbles
// check for 0-9 vs A-F and add appropriate ASCII offsets
// Output each nibble
void LCD_print_hex32(uint8_t row, uint8_t col, uint32_t val)
{
    uint32_t val_tmp;
    LCD_print_char(row, col, '0');
    col++;
    LCD_print_char(row, col, 'x');
    col++;
    val_tmp = val >> 28;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = val & 0x0FFFFFFF;
    val_tmp = val >> 24;
   // printf("%x\n", val_tmp);
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    val_tmp = val & 0x00FFFFFF;
    val_tmp = val_tmp >> 20;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = val & 0x000FFFFF;
    val_tmp = val_tmp >> 16;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = val & 0x0000FFFF;

    val_tmp = val_tmp >> 12;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = val & 0x00000FFF;
    val_tmp = val_tmp >> 8;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = val & 0x000000FF;
    val_tmp = val_tmp >> 4;
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    col++;
    val_tmp = (val & 0x0000000F);
    if(val_tmp < 10)
        LCD_print_char(row, col, val_tmp + 0x30);
    else
        LCD_print_char(row, col, val_tmp + 0x37);
    return;
}


/**
* @brief  Helper function to avoid the use of the math library
*    Calculate POSITIVE powers of 10
* @param  exp exponent
* @retval pow
*/


int pwr10(uint8_t exp)
{
	int8_t i;
	int pow = 1;
	for(i=0; i<exp; i++)
		pow *= 10;
	return pow;
}


/**
* @brief  Display 3 digit unsigned Decimal
*    supports 8 bit unsigned values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_udec3(uint8_t row, uint8_t col, uint8_t val)
{

	int8_t i;
	uint8_t val_tmp = val;
	for(i=2; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}

/**
* @brief  Display 5 digit unsigned Decimal
*    supports 16 bit unsigned values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_udec5(uint8_t row, uint8_t col, uint16_t val)
{

	int8_t i;
	uint16_t val_tmp = val;
	for(i=4; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}


/**
* @brief  Display 10 digit unsigned Decimal
*    supports 32 bit unsigned values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_udec10(uint8_t row, uint8_t col, uint32_t val)
{

	int8_t i;
	uint32_t val_tmp = val;
	for(i=9; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}


/**
* @brief  Display 3 digit signed Decimal
*    supports 8 bit signed values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_dec3(uint8_t row, uint8_t col, int8_t val)
{

	int8_t i;
	int8_t val_tmp = val;
	if(val < 0)
	{
		LCD_print_char(row, col, '-');
		val *= -1;
		val_tmp *= -1;
	}
	else
	{
		LCD_print_char(row, col, ' ');
	}
	col++; // next character position

	for(i=2; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}

/**
* @brief  Display 5 digit signed Decimal
*    supports 16 bit signed values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_dec5(uint8_t row, uint8_t col, int16_t val)
{

	int8_t i;
	int16_t val_tmp = val;
	if(val < 0)
	{
		LCD_print_char(row, col, '-');
		val *= -1;
		val_tmp *= -1;
	}
	else
	{
		LCD_print_char(row, col, ' ');
	}
	col++; // next character position

	for(i=4; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}


/**
* @brief  Display 10 digit signed Decimal
*    supports 32 bit signed values
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_dec10(uint8_t row, uint8_t col, int32_t val)
{

	int8_t i;
	int32_t val_tmp = val;
	if(val < 0)
	{
		LCD_print_char(row, col, '-');
		val *= -1;
		val_tmp *= -1;
	}
	else
	{
		LCD_print_char(row, col, ' ');
	}
	col++; // next character position

	for(i=9; i>=0; i--)
	{
	    if(i == 0 && val == 0)
	    {
	        LCD_print_char(row, col, '0');
	    }
	    else if(val >= (pwr10(i))){
			val_tmp = val_tmp / (pwr10(i));
			LCD_print_char(row, col, val_tmp + 0x30);
		}
		else{
			LCD_print_char(row, col, ' ');
		}
		val_tmp = val % (int)pwr10(i);
		col++; // next character position
	}
}

/**
* @brief  Helper function to avoid the use of the math library
*    Calculate powers of 10 as a float
* @param  exp exponent
* @retval pow
*/

float pwr10f(int8_t exp){
	int8_t i;
	float pow = 1.0;
	if(exp >= 0){
		for(i=0; i<exp; i++)
		pow *= 10;
	}else{
		for(i=0; i>exp; i--)
		pow /= 10;
	}
	return pow;
}

/**
* @brief  Display float in scientific notation
*    x.xxxxExx
* @param  row Row to print in
* @param  col Column to start in
* @param  val value to print
* @retval None
*/

void LCD_print_float(uint8_t row, uint8_t col, float val){
	int8_t exp = -38;
	uint16_t pow = 10000;
	if(val < 0){									// if negative print '-' and make positive
		val *= -1;
		LCD_print_char(row, col, '-');
	}
	else
	{
		LCD_print_char(row, col, ' ');
	}
	col++; // next character position

	while(val >= pwr10f(exp+1))						// calculate exponent
		exp++;

	val = pow * val * pwr10f(0 - exp);				// adjust value to xxxxx.xx form
	val += (pow * FLT_EPSILON * 10);					// since we know magnitude of number - add epsilon*10 to correct for rounding

	int val_tmp = ((int)val);						// now in form xxxxx
	uint8_t i;										// print 1st digit and decimal point
	val_tmp = val / pow;
	val -= val_tmp * pow;
	pow /= 10;
	LCD_print_char(row, col, val_tmp + 0x30);
	col++; // next character position
	LCD_print_char(row, col, '.');
	col++; // next character position
	for(i=1; i<5; i++){								// print remaining digits
		val_tmp = val / pow;
		val -= val_tmp * pow;
		pow /= 10;
		LCD_print_char(row, col, val_tmp + 0x30);
		col++; // next character position
	}
	LCD_print_char(row, col, 'E');							// print E for exponent and '-' if negative
	col++; // next character position
	if(exp < 0){
		LCD_print_char(row, col, '-');
		exp *= -1;
		col++; // next character position
	}
	if(exp > 9)										// print exponent
	{
		LCD_print_char(row, col, (exp / 10) + 0x30);
		col++; // next character position
	}
	LCD_print_char(row, col, (exp % 10) + 0x30);
	// **********************************************
	//krw 2/21/24  - fix for extra digit in row when exponent negative
	//                   add space
	LCD_print_char(row, ++col, ' ');
	// **********************************************
	//krw 5/24/24  - fix for residual exponent digit if zero gets overwritten
	//                   add space
	LCD_print_char(row, ++col, ' ');
}


/**
  * @brief  position the cursor
  * @param  x: specifies the X position.
  * @param  y: specifies the Y position.
  * @retval None
  */
void LCD_SetCursor(uint16_t x, uint16_t y)
{
	st7735_SetCursor( x,  y);
	return;
}

/**
  * @brief  dras a single pixel with the given color
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  RGB_Code: Pixel color in RGB mode (5-6-5)
  * @retval None
*/

void LCD_print_pixel(uint16_t Xpos, uint16_t Ypos, uint16_t RGB_Code)
{
	BSP_LCD_DrawPixel( Xpos,  Ypos,  RGB_Code);
}

/**
  * @brief  Draws a horizontal line.
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  Length: Line length
  * @retval None
  */
void LCD_print_HLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length)
{
	BSP_LCD_DrawHLine( Xpos,  Ypos,  Length);
}

/**
  * @brief  Draws a vertical line.
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  Length: Line length
  * @retval None
  */
void LCD_print_VLine(uint16_t Xpos, uint16_t Ypos, uint16_t Length)
{
	BSP_LCD_DrawVLine( Xpos,  Ypos,  Length);
}

/**
  * @brief  Draws a line (between two points).
  * @param  x1: Point 1 X position
  * @param  y1: Point 1 Y position
  * @param  x2: Point 2 X position
  * @param  y2: Point 2 Y position
  * @retval None
  */
void LCD_print_Line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
	BSP_LCD_DrawLine( x1,  y1,  x2,  y2);
}

/**
  * @brief  Draws a rectangle.
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  Width: Rectangle width
  * @param  Height: Rectangle height
  * @retval None
  */
void LCD_print_Rect(uint16_t Xpos, uint16_t Ypos, uint16_t Width, uint16_t Height)
{
	BSP_LCD_DrawRect( Xpos,  Ypos,  Width,  Height);
}

/**
  * @brief  Draws a circle.
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  Radius: Circle radius
  * @retval None
  */
void LCD_print_Circle(uint16_t Xpos, uint16_t Ypos, uint16_t Radius)
{
	BSP_LCD_DrawCircle( Xpos,  Ypos,  Radius);
}

/**
  * @brief  Draws an ellipse on LCD.
  * @param  Xpos: X position
  * @param  Ypos: Y position
  * @param  XRadius: Ellipse X radius
  * @param  YRadius: Ellipse Y radius
  * @retval None
  */
void LCD_print_Ellipse(int Xpos, int Ypos, int XRadius, int YRadius)
{
	BSP_LCD_DrawEllipse( Xpos,  Ypos,  XRadius,  YRadius);
}

/**
  * @brief  Draws a bitmap picture loaded in the STM32 MCU internal memory.
  * @param  Xpos: Bmp X position in the LCD
  * @param  Ypos: Bmp Y position in the LCD
  * @param  pBmp: Pointer to Bmp picture address
  * @retval None
  */
void LCD_print_Bitmap(uint16_t Xpos, uint16_t Ypos, uint8_t *pBmp)
{
	BSP_LCD_DrawBitmap( Xpos,  Ypos,  pBmp);
}


